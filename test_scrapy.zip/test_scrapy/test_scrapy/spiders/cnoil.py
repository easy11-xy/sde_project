import scrapy
import sys
sys.path.append('..')
from test_scrapy.items import TestScrapyItem

class CnoilSpider(scrapy.Spider):
    name = 'cnoil'
    allowed_domains = ['www.cnoil.com']
    # allowed_domains = ['http://127.0.0.1:5000/']

    #start_urls = ['http://www.cnoil.com/oil/list_{}.html'.format(page) for page in range(1,101)]  #方法1 通过列表推导式构造翻页url
    start_urls = ['http://www.cnoil.com/oil/list_1.html']
    page = 1
    
    def parse(self, response):
        datas = response.xpath('//*[@id="news_tab1"]/div[1]/ul/li')
        for data in datas:
            data_item = TestScrapyItem()
            data_item["title"] = data.xpath("./a/h2/text()").extract()[0]
            data_item["date"] = data.xpath("./div/span[2]/text()").extract()[0]
            yield data_item
        next_page_url = response.url.replace("list_{}".format(self.page),"list_{}".format(self.page+1))  
        self.page += 1
        yield scrapy.Request(next_page_url)
               
            