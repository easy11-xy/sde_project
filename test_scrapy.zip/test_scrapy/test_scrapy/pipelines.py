# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: https://docs.scrapy.org/en/latest/topics/item-pipeline.html


# useful for handling different item types with a single interface
from itemadapter import ItemAdapter
import pymysql

class FilteDatePipeline:
    def process_item(self, item, spider):
        if '中国' in item["title"]:
            return item

class CleanDatePipeline:
    def process_item(self, item, spider):
        if item:
            item["date"] = item["date"].replace("-",":")
            return item

class SaveTxtPipeline:
    def process_item(self, item, spider):
        #print(type(item),item)
        if item:
            with open('原油数据.txt','a',encoding='utf-8') as f:
                f.write(item["title"]+item["date"]+'\n')
            return item
        
class SaveMysqlPipeline:
    def __init__(self):
        self.db = pymysql.connect(host='localhost',
                             user = 'root',
                             password='cat.1013.',
                             port=3306,
                             database='ai')
        self.cursor = self.db.cursor()
        self.create_table()
        
    def create_table(self):
        create_table_sql = '''CREATE TABLE IF NOT EXISTS cnoil(
                      title VARCHAR(100)  COMMENT "新闻名",  
                      date VARCHAR(100) NOT NULL COMMENT "日期"    
                      )ENGINE=InnoDB DEFAULT CHARSET=utf8'''
        self.cursor.execute(create_table_sql)
    
    def process_item(self, item, spider):
        if item:
            insert_sql = "insert into cnoil values('{}','{}')".format(item["title"],item["date"])
            self.cursor.execute(insert_sql)
            self.db.commit()
            return item
